package com.cg.pecunia.exception;

public class LoanException extends Exception {
	public LoanException(String message) {
		super(message);
	}
	public LoanException() {
		super();
	}

}
