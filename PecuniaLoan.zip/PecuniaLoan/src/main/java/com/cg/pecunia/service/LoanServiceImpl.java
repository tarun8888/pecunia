package com.cg.pecunia.service;

import java.util.List;

import com.cg.pecunia.bean.Loan;
import com.cg.pecunia.dao.LoanDao;
import com.cg.pecunia.dao.LoanDaoImpl;
import com.cg.pecunia.exception.LoanException;

public class LoanServiceImpl implements LoanService {
	
	private LoanDao loanDao;
	
	public LoanServiceImpl() {
		loanDao = new LoanDaoImpl();
	}

	public Loan addLoanDetails(String accountId, double amount, int tenure, double rateOfInterest, int creditScore) throws LoanException {
		
		return loanDao.addLoanDetails(accountId, amount, tenure, rateOfInterest, creditScore) ;
	}

	public String createLoanRequest(Loan loan) throws LoanException {
		
		return loanDao.createLoanRequest(loan);
	}

	public List<Loan> loanRequestList() throws LoanException {
		
		return loanDao.loanRequestList();
	}

	@Override
	public List<Loan> loanApprovalList(Loan loan) throws LoanException {
	
		return loanDao.loanApprovalList(loan);
	}

	@Override
	public boolean validateAmount(double amount) {
		
		if(amount>=1000 && amount<=10000000)
			return true;
		return false;
	}

	@Override
	public boolean validateTenure(int tenure) {
		if(tenure>=12 && tenure<=240)
			return true;
		return false;
	}

	@Override
	public boolean validateRateOfInterest(double rateOfInterest) {
		if(rateOfInterest>=4 && rateOfInterest<=15)
			return true;
		return false;
	}

	@Override
	public boolean validateCreditScore(int creditScore) {
		if(creditScore>=100 && creditScore<=999)
			return true;
		return false;
	}

	@Override
	public String loanApprovalStatus(Loan loan, String accountId) throws LoanException {
	
		return loanDao.loanApprovalStatus(loan,accountId);
	}

	@Override
	public double calculateEmiForLoan(Loan loan) throws LoanException {
		
		return loanDao.calculateEmiForLoan(loan);
	}

	@Override
	public boolean validateNumber(String number) throws LoanException {
		// TODO Auto-generated method stub
		return number.matches("[0-9]{12}");
	}

}
